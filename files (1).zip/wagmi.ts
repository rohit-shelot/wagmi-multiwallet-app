import { http, createConfig } from 'wagmi';
import { mainnet, polygon, arbitrum, optimism, base } from 'wagmi/chains';
import { metaMask, coinbaseWallet, walletConnect } from 'wagmi/connectors';

const projectId = 'YOUR_WALLETCONNECT_PROJECT_ID'; // Get from cloud.walletconnect.com

export const config = createConfig({
  chains: [mainnet, polygon, arbitrum, optimism, base],
  connectors: [
    metaMask(),
    coinbaseWallet({ appName: 'Web3 Hub' }),
    walletConnect({ projectId }),
  ],
  transports: {
    [mainnet.id]:  http(),
    [polygon.id]:  http(),
    [arbitrum.id]: http(),
    [optimism.id]: http(),
    [base.id]:     http(),
  },
});
