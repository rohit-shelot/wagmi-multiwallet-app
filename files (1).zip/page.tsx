'use client';

import { useState } from 'react';
import { useAccount, useConnect, useDisconnect, useSwitchChain, useSendTransaction, useSignMessage, useBalance, useChainId } from 'wagmi';
import { parseEther } from 'viem';
import { mainnet, polygon, arbitrum, optimism, base } from 'wagmi/chains';

const CHAINS = [mainnet, polygon, arbitrum, optimism, base];

export default function Home() {
  const { address, isConnected } = useAccount();
  const { connectors, connect, isPending: isConnecting } = useConnect();
  const { disconnect } = useDisconnect();
  const { switchChain, isPending: isSwitching } = useSwitchChain();
  const chainId = useChainId();
  const { data: balance } = useBalance({ address });

  const { sendTransaction, isPending: isSending, isSuccess: isSent, data: txHash } = useSendTransaction();
  const { signMessage, isPending: isSigning, isSuccess: isSigned, data: signature } = useSignMessage();

  const [toAddress, setToAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('Hello from Web3!');
  const [tab, setTab] = useState<'send' | 'sign'>('send');

  const currentChain = CHAINS.find(c => c.id === chainId);

  const walletIcons: Record<string, string> = {
    MetaMask: '🦊',
    Coinbase: '🔵',
    WalletConnect: '🔗',
    Injected: '💉',
  };

  return (
    <main className="min-h-screen bg-[#0a0a0f] text-white font-mono">
      <div className="max-w-2xl mx-auto px-4 py-12">

        {/* Header */}
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-cyan-400 flex items-center justify-center text-xs font-bold">W3</div>
            <h1 className="text-xl font-bold tracking-tight text-white">web3 hub</h1>
          </div>
          <p className="text-zinc-500 text-sm">Multi-wallet · Chain switching · Send · Sign</p>
        </div>

        {!isConnected ? (
          /* Wallet Connect Screen */
          <div className="border border-zinc-800 rounded-2xl p-6 bg-zinc-950">
            <p className="text-zinc-400 text-sm mb-5">Connect your wallet</p>
            <div className="grid grid-cols-1 gap-3">
              {connectors.map(connector => (
                <button
                  key={connector.uid}
                  onClick={() => connect({ connector })}
                  disabled={isConnecting}
                  className="flex items-center gap-3 p-4 border border-zinc-800 rounded-xl hover:border-violet-500 hover:bg-violet-500/5 transition-all duration-200 text-left group"
                >
                  <span className="text-2xl">{walletIcons[connector.name] ?? '👛'}</span>
                  <div>
                    <p className="text-sm font-medium text-white group-hover:text-violet-300 transition-colors">{connector.name}</p>
                    <p className="text-xs text-zinc-600">Click to connect</p>
                  </div>
                  <span className="ml-auto text-zinc-700 group-hover:text-violet-400 transition-colors">→</span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          /* Connected Dashboard */
          <div className="space-y-4">

            {/* Account Card */}
            <div className="border border-zinc-800 rounded-2xl p-5 bg-zinc-950">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-xs text-emerald-400 font-medium">Connected</span>
                  </div>
                  <p className="text-white font-medium text-sm">{address?.slice(0, 6)}...{address?.slice(-4)}</p>
                  <p className="text-zinc-500 text-xs mt-0.5">
                    {balance ? `${parseFloat(balance.formatted).toFixed(4)} ${balance.symbol}` : '—'}
                  </p>
                </div>
                <button
                  onClick={() => disconnect()}
                  className="text-xs text-zinc-600 hover:text-red-400 transition-colors border border-zinc-800 hover:border-red-400/30 px-3 py-1.5 rounded-lg"
                >
                  Disconnect
                </button>
              </div>

              {/* Chain Switcher */}
              <div>
                <p className="text-xs text-zinc-600 mb-2">Network</p>
                <div className="flex flex-wrap gap-2">
                  {CHAINS.map(chain => (
                    <button
                      key={chain.id}
                      onClick={() => switchChain({ chainId: chain.id })}
                      disabled={isSwitching}
                      className={`text-xs px-3 py-1.5 rounded-lg border transition-all duration-150 ${
                        chain.id === chainId
                          ? 'border-violet-500 bg-violet-500/10 text-violet-300'
                          : 'border-zinc-800 text-zinc-500 hover:border-zinc-600 hover:text-zinc-300'
                      }`}
                    >
                      {chain.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Tabs */}
            <div className="border border-zinc-800 rounded-2xl bg-zinc-950 overflow-hidden">
              <div className="flex border-b border-zinc-800">
                {(['send', 'sign'] as const).map(t => (
                  <button
                    key={t}
                    onClick={() => setTab(t)}
                    className={`flex-1 py-3 text-sm font-medium transition-colors ${
                      tab === t ? 'text-white border-b-2 border-violet-500 -mb-px' : 'text-zinc-500 hover:text-zinc-300'
                    }`}
                  >
                    {t === 'send' ? '↑ Send' : '✍ Sign'}
                  </button>
                ))}
              </div>

              <div className="p-5">
                {tab === 'send' ? (
                  <div className="space-y-3">
                    <input
                      type="text"
                      placeholder="Recipient address (0x...)"
                      value={toAddress}
                      onChange={e => setToAddress(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white placeholder-zinc-600 focus:outline-none focus:border-violet-500 transition-colors"
                    />
                    <div className="flex gap-2">
                      <input
                        type="number"
                        placeholder="0.001"
                        value={amount}
                        onChange={e => setAmount(e.target.value)}
                        className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white placeholder-zinc-600 focus:outline-none focus:border-violet-500 transition-colors"
                      />
                      <span className="flex items-center px-4 text-sm text-zinc-500 border border-zinc-800 rounded-xl bg-zinc-900">
                        {currentChain?.nativeCurrency?.symbol ?? 'ETH'}
                      </span>
                    </div>
                    <button
                      onClick={() => sendTransaction({ to: toAddress as `0x${string}`, value: parseEther(amount || '0') })}
                      disabled={isSending || !toAddress || !amount}
                      className="w-full py-3 rounded-xl bg-violet-600 hover:bg-violet-500 disabled:opacity-40 disabled:cursor-not-allowed text-sm font-medium transition-colors"
                    >
                      {isSending ? 'Sending…' : 'Send Transaction'}
                    </button>
                    {isSent && txHash && (
                      <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                        <p className="text-xs text-emerald-400 font-medium">Transaction sent!</p>
                        <p className="text-xs text-zinc-500 mt-1 break-all">{txHash}</p>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-3">
                    <textarea
                      rows={3}
                      placeholder="Message to sign…"
                      value={message}
                      onChange={e => setMessage(e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white placeholder-zinc-600 focus:outline-none focus:border-violet-500 transition-colors resize-none"
                    />
                    <button
                      onClick={() => signMessage({ message })}
                      disabled={isSigning || !message}
                      className="w-full py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 disabled:cursor-not-allowed text-sm font-medium transition-colors"
                    >
                      {isSigning ? 'Signing…' : 'Sign Message'}
                    </button>
                    {isSigned && signature && (
                      <div className="p-3 bg-cyan-500/10 border border-cyan-500/20 rounded-xl">
                        <p className="text-xs text-cyan-400 font-medium">Message signed!</p>
                        <p className="text-xs text-zinc-500 mt-1 break-all font-mono">{signature}</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

          </div>
        )}
      </div>
    </main>
  );
}
